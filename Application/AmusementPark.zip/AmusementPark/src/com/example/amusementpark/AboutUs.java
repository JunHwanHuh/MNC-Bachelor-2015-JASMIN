package com.example.amusementpark;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.graphics.Color;

public class AboutUs extends Activity {
	private ImageView seok, hoon, gyu;
	private TextView txt_seok, txt_hoon, txt_gyu;
	
	protected void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        seok = (ImageView) findViewById(R.id.img_seok);
        gyu = (ImageView) findViewById(R.id.img_gyu);
        hoon = (ImageView) findViewById(R.id.img_hoon); 
        
        txt_seok = (TextView) findViewById(R.id.txt_seok);
        txt_hoon = (TextView) findViewById(R.id.txt_hoon);
        txt_gyu = (TextView) findViewById(R.id.txt_gyu);
        
        txt_gyu.setBackgroundColor((new Color()).rgb(255, 235, 59));
        txt_hoon.setBackgroundColor((new Color()).rgb(255, 235, 59));
        txt_seok.setBackgroundColor((new Color()).rgb(255, 235, 59));
	}
}
