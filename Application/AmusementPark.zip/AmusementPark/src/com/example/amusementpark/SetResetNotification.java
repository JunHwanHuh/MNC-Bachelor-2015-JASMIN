package com.example.amusementpark;

import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class SetResetNotification extends Activity {
	private Button btn_push_set, btn_push_reset;
	private TextView txt_test;
	private ArrayList<String> arr_select_spn;
	private ArrayAdapter<String> adapter;
	private Spinner spn_push_set, spn_push_reset;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setreset);

		btn_push_set = (Button) findViewById(R.id.btn_push_set);
		btn_push_reset = (Button) findViewById(R.id.btn_push_reset);

		txt_test = (TextView) findViewById(R.id.txt_test);

		// spinner
		arr_select_spn = new ArrayList<String>();
		arr_select_spn.add("1�� ���̱ⱸ");
		arr_select_spn.add("2�� ���̱ⱸ");
		arr_select_spn.add("3�� ���̱ⱸ");
		arr_select_spn.add("4�� ���̱ⱸ");
		arr_select_spn.add("5�� ���̱ⱸ");

		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, arr_select_spn);

		spn_push_set = (Spinner) findViewById(R.id.spn_push_set);
		spn_push_set.setPrompt("push �˸��� ������ ���̱ⱸ ����");
		spn_push_set.setAdapter(adapter);
		spn_push_set.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
			}
		});
		// spinner
		arr_select_spn = new ArrayList<String>();
		arr_select_spn.add("ȸ����");
		arr_select_spn.add("����ī");
		arr_select_spn.add("����ŷ");
		arr_select_spn.add("�ͽ�����");
		

		adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, arr_select_spn);

		spn_push_set = (Spinner) findViewById(R.id.spn_push_set);
		spn_push_set.setPrompt("push �˸��� ������ ���̱ⱸ ����");
		spn_push_set.setAdapter(adapter);
		spn_push_set.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
			}
		});

		// push set button
		btn_push_set.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				int rides_num = spn_push_set.getSelectedItemPosition();
				if(rides_num == 0) rides_num=2;
				else if(rides_num == 1) rides_num=3;
				else if(rides_num == 2) rides_num=5;
				else if(rides_num == 3) rides_num=6;
				txt_test.setText(Integer.toString(rides_num));

				/*
				 * 09-06-2015 �����ͺ��̽��� �ߺ����� �ذ��� ���� �ۼ��ߴ� �ڵ����� Ǫ�ð� ���ö� Ǯ ����� ����
				 * �������� �ذ���� if (!check_dup(rides_num)) {
				 * Toast.makeText(getApplicationContext(), "�̹� �˸��� ��ϵ� ���̱ⱸ �Դϴ�"
				 * , Toast.LENGTH_SHORT).show(); return; }
				 */

				Toast.makeText(getApplicationContext(), Integer.toString(rides_num) + "�� ���̱ⱸ�� ���� Ǫ�� �˸��� ��ϵǾ����ϴ�.",
						Toast.LENGTH_SHORT).show();
				String url = "http://52.26.66.52:80/moongoo";
				HttpClient http = new DefaultHttpClient();
				try {
					ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
					// spinner���� �����Ѱɷ� �������� �ؿ��� �ּ��κ��� "0" ��ſ� ������ ��
					nameValuePairs.add(new BasicNameValuePair("camera_idx", Integer.toString(rides_num)));
					nameValuePairs.add(new BasicNameValuePair("regNum",
							"APA91bENem2kXCRxc_TwY6Vstz3xAxxtaudbU7Gb-iAttW_8y-6GT2Fie317QejemwS1LO_OLICqHfaTbBn0PXj_yQ0hHAHi6myQxzXgOW4FkXwIct486MnaDwIPqwjvTNX63MtOCzCY"));

					HttpParams params = http.getParams();

					// ���⼭ 3000�� Ÿ�Ӿƿ� �̸������� ���� ������ 3��
					HttpConnectionParams.setConnectionTimeout(params, 3000);
					HttpConnectionParams.setSoTimeout(params, 3000);

					// ����Ʈ ��ü ����
					HttpPost httpPost = new HttpPost(url);

					// ���ڵ� ���� ������ ���߰� EUC �Ǵ� UTF
					UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "EUC-KR");
					// ����Ƽ ����
					httpPost.setEntity(entityRequest);
					// ��� ����
					HttpResponse responsePost = http.execute(httpPost);
					// �������� ����
					HttpEntity response = responsePost.getEntity();

					// �����κ����� �����ǽ� �׽�Ʈ��
					txt_test.setText(response.toString());
				} catch (Exception e) {
					e.getStackTrace();
				}
			}
		});

		// spinner
		spn_push_reset = (Spinner) findViewById(R.id.spn_push_reset);
		spn_push_reset.setAdapter(adapter);
		spn_push_reset.setOnItemSelectedListener(new OnItemSelectedListener() {
			public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
			}

			@Override
			public void onNothingSelected(AdapterView<?> parent) {
			}
		});

		// push reset button
		btn_push_reset.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				
				int rides_num = spn_push_reset.getSelectedItemPosition();
				if(rides_num == 0) rides_num=2;
				else if(rides_num == 1) rides_num=3;
				else if(rides_num == 2) rides_num=5;
				else if(rides_num == 3) rides_num=6;
				
				
				txt_test.setText(Integer.toString(rides_num));

				/*
				 * if (check_dup(rides_num)) {
				 * Toast.makeText(getApplicationContext(),
				 * Integer.toString(rides_num) + "�� ���̱ⱸ�� �˸��� ��ϵ� ���̱ⱸ�� �ƴմϴ�",
				 * Toast.LENGTH_SHORT).show(); return; }
				 */

				Toast.makeText(getApplicationContext(), Integer.toString(rides_num) + "�� ���̱ⱸ�� ���� Ǫ�� �˸��� �����Ǿ����ϴ�.",
						Toast.LENGTH_SHORT).show();

				String url = "http://52.26.66.52:80/moongoo1";
				HttpClient http = new DefaultHttpClient();
				try {
					ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

					nameValuePairs.add(new BasicNameValuePair("camera_idx", Integer.toString(rides_num)));
					nameValuePairs.add(new BasicNameValuePair("regNum",
							"APA91bENem2kXCRxc_TwY6Vstz3xAxxtaudbU7Gb-iAttW_8y-6GT2Fie317QejemwS1LO_OLICqHfaTbBn0PXj_yQ0hHAHi6myQxzXgOW4FkXwIct486MnaDwIPqwjvTNX63MtOCzCY"));
//APA91bGjrqB5JJlJ9CKR4DrPKRnJ01VvwGhKeaWxV57P_vwo1W6pr9TySxi7wJ5fBAdzTxYXpJ7A7g5KpFL0mdGfyRFy8A98YTN1wJ0OHIudTDLjulVDZ6HvA2OYr31BbMfk3Fd7gFnM
					HttpParams params = http.getParams();
					HttpConnectionParams.setConnectionTimeout(params, 3000);
					HttpConnectionParams.setSoTimeout(params, 3000);

					HttpPost httpPost = new HttpPost(url);
					UrlEncodedFormEntity entityRequest = new UrlEncodedFormEntity(nameValuePairs, "EUC-KR");
					httpPost.setEntity(entityRequest);
					HttpResponse responsePost = http.execute(httpPost);
					HttpEntity response = responsePost.getEntity();

					txt_test.setText(response.toString());
				} catch (Exception e) {
					e.getStackTrace();
				}
			}
		});
	}
}
