package com.example.amusementpark;

import com.google.android.gcm.GCMRegistrar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button btn_check_whole, btn_check_realtime, btn_setreset, btn_about;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);

		btn_check_whole = (Button) findViewById(R.id.btn_check_whole);
		btn_check_whole.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				// ���⿡ ���� �����ָ� ��
				// ���� ���� �ϸ� �ɰž�
				Intent intent = new Intent(MainActivity.this, WebViewActivity_whole.class);
				startActivity(intent);
			}
		});

		btn_check_realtime = (Button) findViewById(R.id.btn_check_realtime);
		btn_check_realtime.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, WebViewActivity_realtime.class);
				startActivity(intent);
			}
		});

		btn_setreset = (Button) findViewById(R.id.btn_setreset);
		btn_setreset.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, SetResetNotification.class);
				startActivity(intent);
			}
		});

		// Gcm ����ϴ� �Լ�
		registerGcm();

		btn_about = (Button) findViewById(R.id.btn_about);
		btn_about.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, AboutUs.class);
				startActivity(intent);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void registerGcm() {

		GCMRegistrar.checkDevice(this);
		GCMRegistrar.checkManifest(this);

		final String regId = GCMRegistrar.getRegistrationId(this);
		Log.e("Check rgst", "hi");
		if (regId.equals("")) {
			GCMRegistrar.register(this, "906477994253"); // ������Ʈ ID project-cse
															// , 906477994253 -
															// ������Ʈ ��ȣ (Sender
															// ID�λ����) ,
															// AIzaSyDQcI322KBj93djTHIxFmPxtFPz1BMvEuM
															// -api����Ű
		} else {
			Log.e("id", regId);
		}
	}
}
