package com.example.amusementpark;

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class WebViewActivity_realtime extends Activity {
	private WebView wb_whole;

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_webview_realtime);

		wb_whole = (WebView) findViewById(R.id.wb_realtime);
		wb_whole.setWebViewClient(new WebViewClient());

		WebSettings set = wb_whole.getSettings();
		set.setJavaScriptEnabled(true);
		set.setBuiltInZoomControls(true);

		wb_whole.loadUrl("http://52.26.66.52/contact");
	}
}